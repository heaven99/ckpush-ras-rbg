/* This provides a crude manner of testing the performance of a broker in messages/s. */

#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include <unistd.h>

#include "mosquitto.h"

#include "jsmn.h"
#include "ckpush-mqtt-load.h"


static bool run = true;
static int message_count = 0;
static struct timeval start, stop;


int jsoneq(const char *json, jsmntok_t *tok, const char *s) {
	if (tok->type == JSMN_STRING && (int) strlen(s) == tok->end - tok->start &&
		strncmp(json + tok->start, s, tok->end - tok->start) == 0) {
		return 0;
	}
	return -1;
}


// found 1, not found 0
int getJSONString (char *pBody, jsmntok_t *t, int r, char *field, char *value, char size)
{
	for (int i = 1; i < r; i++)
	{
		if (jsoneq(pBody, &t[i], field) == 0)
		{
			printf("-JSON.%s = [%.*s]\n",
						field, t[i + 1].end - t[i + 1].start,
						pBody + t[i + 1].start);

			snprintf(value, size, "%.*s", t[i + 1].end - t[i + 1].start, pBody + t[i + 1].start);

			i++;

			return 1;
		}
	}

	return 0;
}



int read_mqtt_conf_data () {
	char 	data[1024 * 10];

	memset(data, 0, sizeof(data));

	FILE *fp = fopen(MQTT_CONFIG_FILE, "rb");
	if (fp == NULL) {
		printf("file open error\n");
		exit(0);
	}

	long readLen = fread(data, 1, 10 * 1024, fp);

	printf("read config file=%s\n", data);

	fclose(fp);



	// INFO: INIT JSON Parser
	jsmn_parser         parser;
	jsmntok_t           t[100];
	jsmn_init(&parser);

	// INFO: 2019.02.08, 아래 변경사항 MAX_JSON_TOKEN 반영되어야 합니다.
	int r = jsmn_parse(&parser, data, strlen(data), t, 100);
	if (r < 0) {
		printf("jsmn_parse error\n");
		return 0;
	}


	// check request
	char value[128];
	int found;

	// for PARAM, set default value
	char host_ip[128] = "";
	int  format = 0;

	found = getJSONString(data, t, r, "host-ip", value, sizeof(value));
	if (found == 1) {
		strncpy(host_ip, value, 128);
		printf("+host_ip=[%s]\n", host_ip);
	}

//	// PARAM format
//	found = getJSONString(pBody, t, r, "format", value, sizeof(value));
//	if (found == 1) {
//		format = atoi(value);
//		PRINT_DEBUG("+format=[%d]\n", format);
//	}


	return readLen;
}


void my_connect_callback(struct mosquitto *mosq, void *obj, int rc)
{
	//printf("rc: %d\n", rc);
	gettimeofday(&start, NULL);

	if (rc != 0) {
		printf("something wrong\n");
		exit(0);
	}
}

void my_disconnect_callback(struct mosquitto *mosq, void *obj, int result)
{
	run = false;
}

void my_publish_callback(struct mosquitto *mosq, void *obj, int mid)
{
	message_count++;
	if(message_count == MESSAGE_COUNT){
		gettimeofday(&stop, NULL);
		mosquitto_disconnect((struct mosquitto *)obj);
	}
}

int read_publish_data (char *data) {
	FILE *fp = fopen(PUBLISH_FILE, "rb");
	if (fp == NULL) {
		printf("file open error\n");
		exit(0);
	}

	long readLen = fread(data, 1, 10 * 1024, fp);

	printf("read file =%ld\n", readLen);

	fclose(fp);

	return readLen;
}


int main(int argc, char *argv[])
{
	struct mosquitto *mosq;
	int i;
	double dstart;
    double dstop;
    double diff;
	uint8_t *buf;
	int ret;

	// init mqtt config
	read_mqtt_conf_data();

	buf = malloc(MESSAGE_SIZE*MESSAGE_COUNT);
	if(!buf){
		printf("Error: Out of memory.\n");
		return 1;
	}

	start.tv_sec = 0;
	start.tv_usec = 0;
	stop.tv_sec = 0;
	stop.tv_usec = 0;

	mosquitto_lib_init();

	mosq = mosquitto_new("mqtt-loader", true, NULL);
	mosquitto_connect_callback_set(mosq, my_connect_callback);
	mosquitto_disconnect_callback_set(mosq, my_disconnect_callback);
	mosquitto_publish_callback_set(mosq, my_publish_callback);


	mosquitto_username_pw_set(mosq, USER_ID, USER_PW);
	ret = mosquitto_connect(mosq, HOST_IP, PORT, 600);
	if (ret != MOSQ_ERR_SUCCESS) {
		printf("connect error");
		exit(0);
	}

	mosquitto_loop_start(mosq);

	char data[1024 * 1024];
	memset(data, 0, 1024 * 1024);
	int  data_len = read_publish_data(data);
	printf("-publish data=%s\n, data len=%d\n", data, data_len);

    // INFO: 2019.01.23, publish start
    // mosquitto_sub -h 127.0.0.1 -p 1883 -t perf/test/#
    // mosquitto_sub -h dev2.ckpush.com -p 6001 -t perf/test/# --pw "NBNynN4iGUsM" --username ckstack
    useconds_t  wait_tick = LOADER_TPS / 10;
    useconds_t  wait_time = 1000000 / 10;
    if (wait_tick == 0) {
        wait_tick = 1;
        wait_time = 1000000;
    }
	printf("--- START MQTT LOAD RUNNER : Count = %ld, LOADER TPS=%ld, wait_tick=%d, wait_time=%d\n", MESSAGE_COUNT, LOADER_TPS, wait_tick, wait_time);

	i=0;
	for(i=1; i<= MESSAGE_COUNT; i++){
        if (i % wait_tick == 0) {
            printf("  -load control (%d)\n", i);
            usleep(wait_time);     // 1000000 / 10
        }

		mosquitto_publish(mosq, NULL, PUBLISH_TOPIC, data_len, data, PUB_QOS, false);

	}
	// INFO: 2019.01.23, publish end
    //

	mosquitto_loop_stop(mosq, false);


//    dstart = (double)start.tv_sec*1.0e6 + (double)start.tv_usec;
//	dstop = (double)stop.tv_sec*1.0e6 + (double)stop.tv_usec;
//	diff = (dstop-dstart)/1.0e6;
    dstart = (double)start.tv_sec * 1000000 + (double)start.tv_usec;
    dstop = (double)stop.tv_sec * 1000000 + (double)stop.tv_usec;
    diff = (dstop - dstart) / 1000000;


	printf("%s", COPYRIGHT_00);
	printf("%s", COPYRIGHT_01);
	printf("%s", COPYRIGHT_05);
	printf("%s", COPYRIGHT_10);
	printf("%s", COPYRIGHT_11);
	printf("%s", COPYRIGHT_12);
	printf("%s", COPYRIGHT_13);
    printf(" MQTT LOAD RUNNER : Count = %ld, LOADER TPS=%ld\n", MESSAGE_COUNT, LOADER_TPS);
    printf("   Diff. time (Sec) : %6.4lf\n   Messages/s (TPS) : %6.1f\n", diff, (double) MESSAGE_COUNT / diff);
	printf("%s", COPYRIGHT_00);


	mosquitto_destroy(mosq);
	mosquitto_lib_cleanup();

	return 0;
}
