#define COPYRIGHT_00    "***********************************************************\n"
#define COPYRIGHT_01    " MQTT LOAD TESTER - LOAD RUNNER \n"
#define COPYRIGHT_02    " MQTT LOAD TESTER - LOAD CHECKER \n"
#define COPYRIGHT_05    " \n"
#define COPYRIGHT_10    " Copyright(C) 2015-2019 CKSTACK CO.,LTD \n"
#define COPYRIGHT_11    " @author befarde (@email chohs@ckstack.com)\n"
#define COPYRIGHT_12    " @license commercial use requires a commercial license.\n"
#define COPYRIGHT_13    "***********************************************************\n"



// DEV1
//#define HOST_IP "39.118.41.11"
//#define PORT 5100
//#define USER_ID "dysystem"
//#define USER_PW "ZaQYN9cVXgp"

// RAS-T30
#define HOST_IP "127.0.0.1"
#define PORT 1883
#define USER_ID "dysystem"
#define USER_PW "ZaQYN9cVXgp"


#define PUBLISH_TOPIC       "000/dysystem/pub/pump/cp/1260DB2A007CK1"
#define SUBSCRIBE_TOPIC     "000/dysystem/pub/pump/vdevice/1260DB2A007CK1"



#define MQTT_CONFIG_FILE    "mqtt-loader.json"
#define PUBLISH_FILE        "mqtt-data.json"

#define PUB_QOS 0
#define SUB_QOS 0

//#define MESSAGE_COUNT 100000L
//#define MESSAGE_SIZE 1024L

#define MESSAGE_SIZE 1024L

#define MESSAGE_COUNT 120L
#define LOADER_TPS  30L