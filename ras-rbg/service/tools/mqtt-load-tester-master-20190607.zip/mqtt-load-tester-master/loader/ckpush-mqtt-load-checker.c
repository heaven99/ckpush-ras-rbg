/* This provides a crude manner of testing the performance of a broker in messages/s. */

#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/time.h>
#include <unistd.h>
#include "mosquitto.h"

#include "ckpush-mqtt-load.h"

// TODO: 2019.01.24, WRITE FILE
// TODO: 2019.01.24,


static bool run = true;
static int message_count = 0;
static struct timeval start, stop;
static struct timeval term_start, term_stop;
FILE *fptr = NULL;


void my_connect_callback(struct mosquitto *mosq, void *obj, int rc)
{
	// printf("rc: %d\n", rc);
	if (rc != 0) {
		printf("something wrong\n");
		exit(0);
	}

}

void my_disconnect_callback(struct mosquitto *mosq, void *obj, int result)
{
	run = false;
}

void my_message_callback(struct mosquitto *mosq, void *obj, const struct mosquitto_message *msg)
{
	if(message_count == 0){
		gettimeofday(&start, NULL);
        gettimeofday(&term_start, NULL);
	}


	// fwrite(msg->payload, sizeof(uint8_t), msg->payloadlen, fptr);

	message_count++;

//    if (message_count % (LOADER_TPS - 1) == 0) {
//        gettimeofday(&term_start, NULL);
//    }

    if(message_count % LOADER_TPS == 0) {
        double dstart, dstop, diff;

        gettimeofday(&term_stop, NULL);
        dstart = (double)term_start.tv_sec*1.0e6 + (double)term_start.tv_usec;
        dstop = (double)term_stop.tv_sec*1.0e6 + (double)term_stop.tv_usec;
        diff = (dstop-dstart)/1.0e6;

        // printf("Start: %g\nStop: %g\nDiff: %g\nMessages (TPS): %g (TPS)\n", dstart, dstop, diff, (double)MESSAGE_COUNT/diff);
        printf("  -Message count=%d,  Diff. Time : %g (usec),  Messages processed : %g (TPS)\n", message_count, diff, (double) LOADER_TPS/diff);

        gettimeofday(&term_start, NULL);
    }


    if(message_count == MESSAGE_COUNT){
		gettimeofday(&stop, NULL);
		mosquitto_disconnect((struct mosquitto *)obj);
	}
}

int main(int argc, char *argv[])
{
	struct mosquitto *mosq;
	double dstart, dstop, diff;
	int mid = 0;
	char id[50];

	start.tv_sec = 0;
	start.tv_usec = 0;
	stop.tv_sec = 0;
	stop.tv_usec = 0;

	fptr = fopen("mqtt-load-checker.dat", "wb");
	if(!fptr){
		printf("Error: Unable to write to reader.dat.\n");
		return 1;
	}
	mosquitto_lib_init();

	snprintf(id, 50, "mqtt-loader-subs-%d", getpid());
	mosq = mosquitto_new(id, true, NULL);
	mosquitto_connect_callback_set(mosq, my_connect_callback);
	mosquitto_disconnect_callback_set(mosq, my_disconnect_callback);
	mosquitto_message_callback_set(mosq, my_message_callback);

	mosquitto_username_pw_set(mosq, USER_ID, USER_PW);
	mosquitto_connect(mosq, HOST_IP, PORT, 600);

	mosquitto_subscribe(mosq, &mid, SUBSCRIBE_TOPIC, SUB_QOS);
    printf("--subscribe topic=[%s]\n", SUBSCRIBE_TOPIC);

	mosquitto_loop_forever(mosq, 10, 1);


    // INFO: 2019.01.24, END of test
	dstart = (double)start.tv_sec*1.0e6 + (double)start.tv_usec;
	dstop = (double)stop.tv_sec*1.0e6 + (double)stop.tv_usec;
	diff = (dstop-dstart)/1.0e6;

	printf("%s", COPYRIGHT_00);
	printf("%s", COPYRIGHT_02);
	printf("%s", COPYRIGHT_05);
	printf("%s", COPYRIGHT_10);
	printf("%s", COPYRIGHT_11);
	printf("%s", COPYRIGHT_12);
	printf("%s", COPYRIGHT_13);
	printf(" MQTT LOAD CHECKER : Received message count = %d/Total(%ld)\n", message_count, MESSAGE_COUNT);
    printf("   Diff. time : %g (usec) \n   Messages (TPS): %g (TPS)\n", diff, (double) MESSAGE_COUNT/diff);
	printf("%s", COPYRIGHT_00);



	mosquitto_destroy(mosq);
	mosquitto_lib_cleanup();
	fclose(fptr);

	return 0;
}
